
 const track = document.getElementById("carouselTrack");

  function scrollRight() {
    track.scrollLeft += 300;
  }

  function scrollLeftBtn() {
    track.scrollLeft -= 300;
  }